﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using System.Windows.Forms;

namespace _301050581_SinaSeylani_Test1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private ObservableCollection<dasda> fruitMenu;
        public ObservableCollection<dasda> fruitGridMenu = new ObservableCollection<dasda>() { };
        private ObservableCollection<dasda> plantMenu;
        public ObservableCollection<dasda> plantGirdMenu = new ObservableCollection<dasda>() { };
        public ObservableCollection<dasda> datagrid3 = new ObservableCollection<dasda>() { };


        public MainWindow()
        {
            InitializeComponent();
            LoadData();
            dgFruit.ItemsSource = fruitGridMenu;
            dgPlant.ItemsSource = plantGirdMenu;
            dg3.ItemsSource = datagrid3;

        }

        public void LoadData()
        {
            fruitMenu = new ObservableCollection<dasda>()
            {
                new dasda(){ObjectName = "WaterMelon",ObjectColor="Red"},
                new dasda(){ObjectName = "Apple",ObjectColor="Yellow"},
                new dasda(){ObjectName = "Orange",ObjectColor="Orange"},
                new dasda(){ObjectName = "Mint",ObjectColor="LightGeen"},

            };
            plantMenu = new ObservableCollection<dasda>()
            {
                new dasda(){ObjectName = "Aloe Vera",ObjectColor="Green"},
                new dasda(){ObjectName = "Cactus",ObjectColor="Green"},
                new dasda(){ObjectName = "Argyroderma ",ObjectColor="Green"},
                new dasda(){ObjectName = "Mint",ObjectColor="Green"},
            };

            LoadFruits(fruitMenu);
            LoadPlants(plantMenu);
        }

        private void LoadFruits(ObservableCollection<dasda> fruitMenu)
        {
           // cbFruit.Items.Add("Fruit");
            cbFruit.SelectedIndex = -1;
            foreach (dasda f in fruitMenu)
            {
                cbFruit.Items.Add(f.ObjectName);
            }
        }
        private void LoadPlants(ObservableCollection<dasda> plantMenu)
        {
           // cbPlant.Items.Add("Plant");
            cbPlant.SelectedIndex = -1;
            foreach (dasda f in plantMenu)
            {
                cbPlant.Items.Add(f.ObjectName);
            }
        }

        private void FruitDropDown(object sender, EventArgs e)
        {
            if (cbFruit.Text != "Fruit")
            {
                dasda selectedFruit = fruitMenu.FirstOrDefault(r => r.ObjectName == cbFruit.Text);
                fruitGridMenu.Add(new dasda() { ObjectName = cbFruit.Text, ObjectColor = selectedFruit.ObjectColor });
            }
               
        }
        private void PlantDropDown(object sender, EventArgs e)
        {
            if (cbPlant.Text != "Plant")
            {
                dasda selectedPlant = plantMenu.FirstOrDefault(r => r.ObjectName == cbPlant.Text);
                plantGirdMenu.Add(new dasda() { ObjectName = cbPlant.Text, ObjectColor = selectedPlant.ObjectColor });
            }

        }

        private void clear(object sender, RoutedEventArgs e)
        {
            fruitGridMenu.Clear();
            plantGirdMenu.Clear();
            cbFruit.SelectedIndex = -1;
            cbPlant.SelectedIndex = -1;

        }

        private void doubleClick(object sender, RoutedEventArgs e)
        {
           // this.Hide();
            dasda mFruit = dgFruit.SelectedItem as dasda;

            foreach (dasda c2 in plantMenu)
            {
                if (mFruit.ObjectName == c2.ObjectName)
                {
                    Console.WriteLine(mFruit.ObjectName);
                    datagrid3.Add(mFruit);
                }

            }

        }
        private void doubleClickPlant(object sender, RoutedEventArgs e)
        {
            // this.Hide();
            dasda mPlant = dgPlant.SelectedItem as dasda;

            foreach (dasda c2 in fruitMenu)
            {
                if (mPlant.ObjectName == c2.ObjectName)
                {
                    Console.WriteLine(mPlant.ObjectName);
                    datagrid3.Add(mPlant);
                }

            }

        }
        private void deleteItem(object sender, RoutedEventArgs e)
        {



            if (dgFruit.SelectedItem != null)
            {
                fruitGridMenu.Remove((dasda)dgFruit.SelectedItem);
            }
            if (dgPlant.SelectedItem != null)
            {
                plantGirdMenu.Remove((dasda)dgPlant.SelectedItem);
            }




        }


        private void dgFruit_SelectedCellsChanged(object sender, SelectedCellsChangedEventArgs e)
        {
            
                dgPlant.SelectedItem = null;



        }

        private void dgPlant_SelectedCellsChanged(object sender, SelectedCellsChangedEventArgs e)
        {
            dgFruit.SelectedItem = null;
        }
    }
}
