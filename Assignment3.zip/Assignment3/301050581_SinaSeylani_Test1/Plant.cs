﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;

namespace _301050581_SinaSeylani_Test1
{
  public  class dasda : INotifyPropertyChanged
    {
        private string plantName;
        private string plantColor;

        public string ObjectName
        {
            get { return plantName; }
            set
            {
                if (plantName != value)
                {
                    plantName = value;
                    OnPropertyChanged("PlantName");

                }

            }
        }
        public string ObjectColor
        {
            get { return plantColor; }
            set
            {
                if (plantColor != value)
                {
                    plantColor = value;
                    OnPropertyChanged("PlantColor");

                }

            }
        }
        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string property)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }


    }
}