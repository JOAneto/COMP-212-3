﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;

namespace _301050581_SinaSeylani_Test1
{
  public  class Object:INotifyPropertyChanged
    {
        private string Name;
        private string Color;

        public string ObjectName
        {
            get { return Name; }
            set
            {
                if(Name != value)
                {
                    Name = value;
                    OnPropertyChanged("ObjectName");
                    
                }

            }
        }
        public string ObjectColor
        {
            get { return Color; }
            set
            {
                if (Color != value)
                {
                    Color = value;
                    OnPropertyChanged("ObjectColor");

                }

            }
        }
        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string property)
        {
            if(PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }


    }
}
